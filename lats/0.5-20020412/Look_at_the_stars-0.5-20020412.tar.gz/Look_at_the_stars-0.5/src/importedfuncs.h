/*
 * Thanks to gqview :) filelist.c text conversation utils
 * It is really great! ...the best one I could find :)
*/

#include <gnome.h>

gchar *text_from_size(int size);

gchar *text_from_time(time_t t);

gchar *text_from_var(int size); // something like text_from_size()
