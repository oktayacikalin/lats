#include <gnome.h>

gboolean
isimage	(char *filename);

gboolean
isdir (char *filename);

GdkPixbuf
*get_thumbnail ( char *filename, int FORCE_RELOAD );

void
read_dir_from_combo_thread ( int FORCE_RELOAD );

void
read_dir_from_combo_start_thread ( int FORCE_RELOAD );

void
read_dir_from_combo	( int FORCE_RELOAD, gpointer user_data);

void
go_to_previous_image_in_list ( void );

void
go_to_next_image_in_list ( void );
