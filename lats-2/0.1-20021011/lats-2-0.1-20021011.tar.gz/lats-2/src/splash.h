#include <gnome.h>


void
refresh_screen ( void ) ;

void
update_screen ( void ) ;

void
show_splash_screen ( void ) ;

void
show_splash_message ( char *message ) ;

void
hide_splash_screen_thread ( void ) ;

void
hide_splash_screen ( void ) ;
