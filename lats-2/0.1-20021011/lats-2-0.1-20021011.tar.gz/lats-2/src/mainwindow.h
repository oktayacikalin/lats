#include <gnome.h>

void
create_mainwindow ( void ) ;

void
display_mainwindow ( void ) ;

void
quit_lats ( void ) ;

