#include <gnome.h>

void
on_home_button_clicked ( GtkButton *button, gpointer user_data ) ;

void
on_zoom_smaller_button_clicked ( GtkButton *button, gpointer user_data ) ;

void
on_zoom_entry_changed ( GtkEntry *entry, gpointer user_data ) ;

void
on_zoom_bigger_button_clicked ( GtkButton *button, gpointer user_data ) ;

void
on_zoom_100_button_clicked ( GtkButton *button, gpointer user_data ) ;

void
on_zoom_fit_button_clicked ( GtkButton *button, gpointer user_data ) ;
